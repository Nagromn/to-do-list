import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";

const NotFound = () => {
  return (
    <Container>
      <Row>
        <h1>Page non trouvée</h1>
      </Row>
    </Container>
  );
};

export default NotFound;
