import "./App.css";
import { Route, Routes } from "react-router-dom";
import Home from "./pages/Home.jsx";
import AddTask from "./pages/AddTask.jsx";
import NotFound from "./pages/NotFound.jsx";
import Layout from "./components/Layout.jsx";


function App() {
  return (
    <Routes>
      <Route element={<Layout/>}>
        <Route index element={<Home />} />
        <Route path="ajouter-une-tache" element={<AddTask />} />
        <Route path="*" element={<NotFound/>} />
      </Route>
    </Routes>
  );
}

export default App;
